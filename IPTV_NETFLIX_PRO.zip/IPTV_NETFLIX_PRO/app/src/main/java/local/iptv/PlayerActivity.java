package local.iptv;

import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.graphics.Color;
import android.view.Gravity;

import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.ui.PlayerView;

public class PlayerActivity extends Activity {
    public static final String EXTRA_URL = "stream_url";
    public static final String EXTRA_TITLE = "stream_title";
    private ExoPlayer player;
    private PlayerView playerView;
    private TextView status;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private String url;
    private String title;
    private int retries = 0;
    private boolean released = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        url = getIntent().getStringExtra(EXTRA_URL);
        title = getIntent().getStringExtra(EXTRA_TITLE);
        if (url == null || url.trim().isEmpty()) { finish(); return; }

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        playerView = new PlayerView(this);
        playerView.setUseController(true);
        playerView.setControllerAutoShow(true);
        root.addView(playerView, new FrameLayout.LayoutParams(-1, -1));
        status = new TextView(this);
        status.setTextColor(Color.WHITE);
        status.setTextSize(14);
        status.setBackgroundColor(0x99000000);
        status.setPadding(24, 12, 24, 12);
        status.setText("Conectando…  " + (title == null ? "" : title));
        FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.START);
        root.addView(status, sp);
        setContentView(root);
        initializePlayer();
    }

    private void initializePlayer() {
        DefaultHttpDataSource.Factory http = new DefaultHttpDataSource.Factory()
            .setUserAgent("IPTVNetflix/1.1 (Android)")
            .setConnectTimeoutMs(15000)
            .setReadTimeoutMs(30000)
            .setAllowCrossProtocolRedirects(true);
        player = new ExoPlayer.Builder(this)
            .setMediaSourceFactory(new DefaultMediaSourceFactory(this).setDataSourceFactory(http))
            .build();
        playerView.setPlayer(player);
        player.addListener(new Player.Listener() {
            @Override public void onPlaybackStateChanged(int state) {
                if (state == Player.STATE_BUFFERING) showStatus("Cargando emisión…");
                else if (state == Player.STATE_READY) { retries = 0; hideStatus(); }
                else if (state == Player.STATE_ENDED) showStatus("La emisión ha terminado");
            }
            @Override public void onPlayerError(PlaybackException error) { retryOrShow(error); }
        });
        MediaItem.Builder item = new MediaItem.Builder().setUri(Uri.parse(url));
        String lower = url.toLowerCase();
        if (lower.contains(".m3u8")) item.setMimeType(MimeTypes.APPLICATION_M3U8);
        else if (lower.matches(".*\\.mpd([?#].*)?$")) item.setMimeType(MimeTypes.APPLICATION_MPD);
        player.setMediaItem(item.build());
        player.prepare();
        player.setPlayWhenReady(true);
    }

    private void retryOrShow(PlaybackException error) {
        if (released) return;
        if (retries < 5) {
            int attempt = ++retries;
            long delay = Math.min(1000L * attempt, 5000L);
            showStatus("Señal interrumpida. Reconectando " + attempt + "/5…");
            handler.postDelayed(() -> {
                if (released || player == null) return;
                player.seekToDefaultPosition();
                player.prepare();
                player.setPlayWhenReady(true);
            }, delay);
        } else {
            showStatus("No se puede reproducir esta emisión. Comprueba la señal o prueba VLC.");
        }
    }

    private void showStatus(String text) { if (status != null) { status.setText(text); status.setVisibility(View.VISIBLE); } }
    private void hideStatus() { if (status != null) status.setVisibility(View.GONE); }

    @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) { finish(); return true; }
        return super.onKeyDown(keyCode, event);
    }

    @Override protected void onStart() { super.onStart(); if (player != null) player.play(); }
    @Override protected void onStop() { super.onStop(); if (player != null) player.pause(); }
    @Override protected void onDestroy() {
        released = true;
        handler.removeCallbacksAndMessages(null);
        if (playerView != null) playerView.setPlayer(null);
        if (player != null) { player.release(); player = null; }
        super.onDestroy();
    }
}
