package local.iptv;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView web;
    private ValueCallback<Uri[]> chooser;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setUserAgentString(s.getUserAgentString() + " IPTVNetflix/1.1");
        web.setBackgroundColor(0xFF141414);
        web.addJavascriptInterface(new Bridge(), "AndroidNative");
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (chooser != null) chooser.onReceiveValue(null);
                chooser = cb;
                try { startActivityForResult(params.createIntent(), 1); return true; }
                catch (Exception e) { chooser = null; cb.onReceiveValue(null); return false; }
            }
        });
        web.loadUrl("file:///android_asset/index.html");
        web.requestFocus();
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && chooser != null) {
            chooser.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
            chooser = null;
        }
    }

    private class Bridge {
        @JavascriptInterface public void playNative(String url, String title) {
            runOnUiThread(() -> {
                Intent i = new Intent(MainActivity.this, PlayerActivity.class);
                i.putExtra(PlayerActivity.EXTRA_URL, url);
                i.putExtra(PlayerActivity.EXTRA_TITLE, title);
                startActivity(i);
            });
        }
        @JavascriptInterface public boolean openVlc(String url) {
            try {
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setDataAndType(Uri.parse(url), "video/*");
                i.setPackage("org.videolan.vlc");
                startActivity(i);
                return true;
            } catch (ActivityNotFoundException e) {
                try {
                    Intent j = new Intent(Intent.ACTION_VIEW);
                    j.setDataAndType(Uri.parse(url), "video/*");
                    startActivity(Intent.createChooser(j, "Abrir con"));
                    return true;
                } catch (Exception x) { return false; }
            } catch (Exception e) { return false; }
        }
        @JavascriptInterface public void keyboard() {
            runOnUiThread(() -> {
                web.requestFocus();
                InputMethodManager m = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                if (m != null) m.showSoftInput(web, InputMethodManager.SHOW_FORCED);
            });
        }
    }

    @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            web.evaluateJavascript("(function(){var m=document.getElementById('modal');if(m&&m.classList.contains('on')){closeM();return 1}return 0})()", value -> {
                if (!"1".equals(value)) finish();
            });
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override protected void onDestroy() {
        if (web != null) { web.loadUrl("about:blank"); web.removeJavascriptInterface("AndroidNative"); web.destroy(); web = null; }
        super.onDestroy();
    }
}
